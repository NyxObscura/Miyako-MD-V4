/* 
『WARNING』 WATERMARK INI TIDAK BOLEH DI HAPUS
* SCRIPT BY XENZ
* CODE BY XENZ
* NAMA SCRIPT MIYAKO-TSUKIYUKI
* JANGAN DI HAPUS KONTOL
* FOLLOW SALURAN XENZ
https://whatsapp.com/channel/0029ValeNDG0LKZLbAQZNs0i
*/

import { happymod } from "../lib/scrape.js";
let handler = async (m, { text, command, usedPrefix }) => {
  if (!text)
    return m.reply(`Masukan Query!\n\nContoh:\n${usedPrefix + command} minecraft`);
  let result = await happymod(text);
  let teks = result
    .map((v, i) => {
      return `
*${i + 1}.* ${v.name}
❃ Link: ${v.link}
`.trim();
    })
    .filter((v) => v)
    .join("\n\n\n");
  await m.reply(teks);
};
handler.help = ["happymod"];
handler.tags = ["internet"];
handler.command = /^happymod$/i;
export default handler;
