/* 
『WARNING』 WATERMARK INI TIDAK BOLEH DI HAPUS
* SCRIPT BY XENZ
* CODE BY XENZ
* NAMA SCRIPT MIYAKO-TSUKIYUKI
* JANGAN DI HAPUS KONTOL
* FOLLOW SALURAN XENZ
https://whatsapp.com/channel/0029ValeNDG0LKZLbAQZNs0i
*/

export async function all(m) {
  const setting = global.db.data.settings[this.user.jid];
  if (setting.autoRestock) {
    if (new Date() * 1 - setting.autoRestockCD > 86400000) {
      let data = Object.entries(global.db.data.bots.stock);
      for (let v of data) {
        if (v[1] == 0) {
          global.db.data.bots.stock[v[0]] += 100000;
        }
      }
      setting.autoRestockCD = new Date() * 1;
    }
  }
  return !0;
}
