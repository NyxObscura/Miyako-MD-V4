/* 
『WARNING』 WATERMARK INI TIDAK BOLEH DI HAPUS
* SCRIPT BY DEXZZ
* NAMA SCRIPT EMILIA-MD
* JANGAN DI HAPUS KONTOL
* FOLLOW SALURAN DEXZZ
https://whatsapp.com/channel/0029ValeNDG0LKZLbAQZNs0i
*/
import fetch from "node-fetch";

const handler = async (m, { text, conn }) => {
  if (!text) return m.reply("mau nanyain apa?");
  await m.reply("_you ai Thinking_");
  const you = await fetch(`https://api.maher-zubair.tech/ai/youai?q=${text}`);
  const youu = await you.json();
  if (youu.status === 400) return m.reply("error");
  await conn.footerTxt(m.chat, "You-Ai", youu.result, m);
};

handler.command = ["youai", "you", "aiyou"];
handler.help = ["youai <query>"];
handler.tags = ["ai"];
handler.limit = true; handler.error = 0
export default handler;
