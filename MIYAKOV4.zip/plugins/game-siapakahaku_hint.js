/* 
『WARNING』 WATERMARK INI TIDAK BOLEH DI HAPUS
* SCRIPT BY XENZ
* CODE BY XENZ
* NAMA SCRIPT MIYAKO-TSUKIYUKI
* JANGAN DI HAPUS KONTOL
* FOLLOW SALURAN XENZ
https://whatsapp.com/channel/0029ValeNDG0LKZLbAQZNs0i
*/

let handler = async (m, { conn }) => {
  conn.siapakahaku = conn.siapakahaku ? conn.siapakahaku : {};
  let id = m.chat;
  if (!(id in conn.siapakahaku)) return;
  let json = conn.siapakahaku[id][1];
  let ans = json.jawaban;
  let clue = ans.replace(/[bcdfghjklmnpqrstvwxyz]/gi, "_");
  m.reply(
    "Clue : " +
      "```" +
      clue +
      "```" +
      "\n\n_*Jangan Balas Chat Ini Tapi Balas Soalnya*_",
  );
};
handler.command = /^(who)$/i;
handler.limit = true; handler.error = 0
export default handler;
