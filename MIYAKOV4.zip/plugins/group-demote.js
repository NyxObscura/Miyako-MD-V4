/* 
『WARNING』 WATERMARK INI TIDAK BOLEH DI HAPUS
* SCRIPT BY XENZ
* CODE BY XENZ
* NAMA SCRIPT MIYAKO-TSUKIYUKI
* JANGAN DI HAPUS KONTOL
* FOLLOW SALURAN XENZ
https://whatsapp.com/channel/0029ValeNDG0LKZLbAQZNs0i
*/

import { areJidsSameUser } from "@adiwajshing/baileys";
let handler = async (m, { conn, participants }) => {
  let users = m.mentionedJid.filter((u) => !areJidsSameUser(u, conn.user.id));
  let user = m.mentionedJid && m.mentionedJid[0];
  if (!user) return m.reply("Tag orang yang mau di Demote!");
  await conn.groupParticipantsUpdate(m.chat, [user], "demote");
  m.reply("Succes");
};
handler.help = ["demote"];
handler.tags = ["group"];
handler.command = /^(demote)$/i;

handler.admin = true;
handler.group = true;
handler.botAdmin = true;

export default handler;
