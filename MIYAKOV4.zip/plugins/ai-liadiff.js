/* 
『WARNING』 WATERMARK INI TIDAK BOLEH DI HAPUS
* SCRIPT BY DEXZZ
* NAMA SCRIPT EMILIA-MD
* JANGAN DI HAPUS KONTOL
* FOLLOW SALURAN DEXZZ
https://whatsapp.com/channel/0029ValeNDG0LKZLbAQZNs0i
*/
let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) return m.reply(`*• Example:* ${usedPrefix + command} cat`);
  m.reply(wait);
  try {
    let gpt = await (
      await fetch(`https://itzpire.site/ai/emi?prompt=${text}`)
    ).json();
    conn.sendFile(
      m.chat,
      gpt.result,
      null,
      "*[ Lia - DIFFUSION ]* " + "\n*• Prompt:* " + text,
    );
  } catch (e) {
    m.reply("`*Command Not Responded*`");
  }
};
handler.help = ["liadiff"];
handler.tags = ["ai"];
handler.command = ["liadiff"];
handler.limit = true; handler.error = 0
handler.onlyprem = true;
export default handler;
