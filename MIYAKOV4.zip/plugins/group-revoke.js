/* 
『WARNING』 WATERMARK INI TIDAK BOLEH DI HAPUS
* SCRIPT BY XENZ
* CODE BY XENZ
* NAMA SCRIPT MIYAKO-TSUKIYUKI
* JANGAN DI HAPUS KONTOL
* FOLLOW SALURAN XENZ
https://whatsapp.com/channel/0029ValeNDG0LKZLbAQZNs0i
*/

let handler = async (m, { conn }) => {
  let res = await conn.groupRevokeInvite(m.chat);
  conn.reply(
    m.sender,
    "https://chat.whatsapp.com/" + (await conn.groupInviteCode(m.chat)),
    m,
  );
};
handler.help = ["revoke"];
handler.tags = ["group"];
handler.command = /^re(voke|new)(invite|link)?$/i;
handler.group = true;
handler.admin = true;
handler.botAdmin = true;

export default handler;
