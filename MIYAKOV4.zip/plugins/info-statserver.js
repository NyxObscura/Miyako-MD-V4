/* 
『WARNING』 WATERMARK INI TIDAK BOLEH DI HAPUS
* SCRIPT BY XENZ
* CODE BY XENZ
* NAMA SCRIPT MIYAKO-TSUKIYUKI
* JANGAN DI HAPUS KONTOL
* FOLLOW SALURAN XENZ
https://whatsapp.com/channel/0029ValeNDG0LKZLbAQZNs0i
*/

import cp from "child_process";
import { promisify } from "util";
let exec = promisify(cp.exec).bind(cp);
let handler = async (m) => {
  let o;
  try {
    o = await exec("df -h");
  } catch (e) {
    o = e;
  } finally {
    let { stdout, stderr } = o;
    if (stdout.trim()) m.reply(stdout);
    if (stderr.trim()) m.reply(stderr);
  }
};
handler.help = ["statserver"];
handler.tags = ["info"];
handler.command = /^(statserver)$/i;

export default handler;
