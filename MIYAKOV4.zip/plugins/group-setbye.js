/* 
『WARNING』 WATERMARK INI TIDAK BOLEH DI HAPUS
* SCRIPT BY XENZ
* CODE BY XENZ
* NAMA SCRIPT MIYAKO-TSUKIYUKI
* JANGAN DI HAPUS KONTOL
* FOLLOW SALURAN XENZ
https://whatsapp.com/channel/0029ValeNDG0LKZLbAQZNs0i
*/

let handler = async (
  m,
  { conn, text, isROwner, isOwner, isAdmin, usedPrefix, command },
) => {
  if (text) {
    global.db.data.chats[m.chat].sBye = text;
    m.reply("Bye Berhasil Diatur...\n@user [mention]");
  } else m.reply(`Teksnya Mana..\nContoh:\nSelamat Tinggal Beban @user`);
};
handler.help = ["setbye"];
handler.tags = ["group"];
handler.command = /^(setbye)$/i;
handler.group = true;
handler.admin = true;

export default handler;
