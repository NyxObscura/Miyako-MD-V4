/* 
『WARNING』 WATERMARK INI TIDAK BOLEH DI HAPUS
* SCRIPT BY XENZ
* CODE BY XENZ
* NAMA SCRIPT MIYAKO-TSUKIYUKI
* JANGAN DI HAPUS KONTOL
* FOLLOW SALURAN XENZ
https://whatsapp.com/channel/0029ValeNDG0LKZLbAQZNs0i
*/

let handler = async (m, { text }) => {
  if (!text) return m.reply("Isinya ?");
  await conn.groupUpdateDescription(m.chat, text);
  return m.reply("Done.");
};
handler.help = ["setdesc"];
handler.tags = ["group"];
handler.command = /^(setdesc|sdesc)$/i;

handler.group = true;
handler.admin = true;

export default handler;
