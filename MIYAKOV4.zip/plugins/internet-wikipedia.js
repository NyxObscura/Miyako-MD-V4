/* 
『WARNING』 WATERMARK INI TIDAK BOLEH DI HAPUS
* SCRIPT BY DEXZZ
* NAMA SCRIPT EMILIA-MD
* JANGAN DI HAPUS KONTOL
* FOLLOW SALURAN DEXZZ
https://whatsapp.com/channel/0029ValeNDG0LKZLbAQZNs0i
*/
import { wikipedia } from "../lib/scrape.js";
let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) return conn.reply(m.chat, "Masukan Query Yang Ingin Dicari!", m);
  let res = await wikipedia(text);
  res[0].thumb
    ? conn.sendFile(m.chat, res[0].thumb, text + ".jpeg", res[0].wiki, m, false)
    : conn.reply(m.chat, res[0].wiki, m);
};
handler.help = ["wikipedia"];
handler.tags = ["internet"];
handler.command = /^(wikipedia)$/i;
export default handler;
