/* 
『WARNING』 WATERMARK INI TIDAK BOLEH DI HAPUS
* SCRIPT BY DEXZZ
* NAMA SCRIPT EMILIA-MD
* JANGAN DI HAPUS KONTOL
* FOLLOW SALURAN DEXZZ
https://whatsapp.com/channel/0029ValeNDG0LKZLbAQZNs0i
*/
let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) m.reply(`*• Example:* ${usedPrefix + command} cat`);
  m.reply(wait);
  try {
    let gpt = await (
      await fetch(`https://itzpire.site/ai/render3d?prompt=${text}`)
    ).json();
    conn.sendFile(
      m.chat,
      gpt.result,
      null,
      "*[ RENDER - 3D ]* " + "\n*• Prompt:* " + text,
    );
  } catch (e) {
    m.reply("`*Command Not Responded*`");
  }
};
handler.help = ["render3d"];
handler.tags = ["ai"];
handler.command = ["render3d"];
export default handler;
