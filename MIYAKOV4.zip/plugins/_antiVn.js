/* 
『WARNING』 WATERMARK INI TIDAK BOLEH DI HAPUS
* SCRIPT BY XENZ
* CODE BY XENZ
* NAMA SCRIPT MIYAKO-TSUKIYUKI
* JANGAN DI HAPUS KONTOL
* FOLLOW SALURAN XENZ
https://whatsapp.com/channel/0029ValeNDG0LKZLbAQZNs0i
*/

export async function before(m, { isAdmin, isBotAdmin }) {
  let isVn = m.mtype;
  let chat = global.db.data.chats[m.chat];
  if (chat.antiVn) {
    if (/opus/i.test(isVn)) {
      if (!isAdmin || isBotAdmin) {
        this.sendMessage(m.chat, { delete: m.key });
      }
    }
  }
  return !0;
}
