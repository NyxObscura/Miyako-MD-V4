/* 
『WARNING』 WATERMARK INI TIDAK BOLEH DI HAPUS
* SCRIPT BY XENZ
* CODE BY XENZ
* NAMA SCRIPT MIYAKO-TSUKIYUKI
* JANGAN DI HAPUS KONTOL
* FOLLOW SALURAN XENZ
https://whatsapp.com/channel/0029ValeNDG0LKZLbAQZNs0i
*/

import { pinterest } from "../lib/scrape.js";

let handler = async (m, { conn, command, usedPrefix, text }) => {
  global.db.data.settings[conn.user.jid].loading
    ? await m.reply(global.config.loading)
    : false;
  let image = await pinterest("cosplaystyle anime");
  conn.sendFile(
    m.chat,
    "https://external-content.duckduckgo.com/iu/?u=" + image,
    false,
    "Ini Dia Kak",
    m,
  );
};
handler.help = ["cosplay"];
handler.tags = ["anime"];
handler.command = /^(cosplay)$/i;

export default handler;
