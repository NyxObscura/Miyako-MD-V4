/* 
『WARNING』 WATERMARK INI TIDAK BOLEH DI HAPUS
* SCRIPT BY XENZ
* CODE BY XENZ
* NAMA SCRIPT MIYAKO-TSUKIYUKI
* JANGAN DI HAPUS KONTOL
* FOLLOW SALURAN XENZ
https://whatsapp.com/channel/0029ValeNDG0LKZLbAQZNs0i
*/

import { topAnime } from "../lib/scrape.js";
let handler = async (m, { conn }) => {
  let anime = await topAnime();
  let caption = anime
    .map((v) => {
      return `
_*${v.rank}. ${v.title}*_
• Rating : ${v.rating}
• ${v.info}
`.trim();
    })
    .join("\n\n");
  m.reply("_*Top Anime Menurut MyAnimeList*_\n\n" + caption);
};
handler.help = ["topanime"];
handler.tags = ["anime"];
handler.command = /^(topanime)$/i;

export default handler;
