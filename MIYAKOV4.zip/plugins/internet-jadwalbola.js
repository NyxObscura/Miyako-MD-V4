/* 
『WARNING』 WATERMARK INI TIDAK BOLEH DI HAPUS
* SCRIPT BY DEXZZ
* NAMA SCRIPT EMILIA-MD
* JANGAN DI HAPUS KONTOL
* FOLLOW SALURAN DEXZZ
https://whatsapp.com/channel/0029ValeNDG0LKZLbAQZNs0i
*/
import fetch from "node-fetch";
let handler = async (m, { command, usedPrefix }) => {
  let f = await fetch(
    API("https://api.lolhuman.xyz", "/api/jadwalbola", null, "apikey"),
  );
  let xx = await f.json();
  let teks = xx.result
    .map((v) => {
      return `  
_*${v.match}*_
🏆Event: ${v.event}
⏲️Waktu: _${v.time}_
📺Channel Tv: ${v.tv}
      `.trim();
    })
    .filter((v) => v)
    .join("\n\n");
  await m.reply(teks);
};
handler.help = ["jadwalbola"];
handler.tags = ["internet"];
handler.command = /^jadwalbola$/i;
export default handler;
