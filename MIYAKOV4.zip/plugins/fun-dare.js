/* 
『WARNING』 WATERMARK INI TIDAK BOLEH DI HAPUS
* SCRIPT BY DEXZZ
* NAMA SCRIPT EMILIA-MD
* JANGAN DI HAPUS KONTOL
* FOLLOW SALURAN DEXZZ
https://whatsapp.com/channel/0029ValeNDG0LKZLbAQZNs0i
*/
import { dare } from "@bochilteam/scraper";

let handler = async (m, { conn, usedPrefix }) => {
  m.reply(await dare());
};
handler.help = ["dare"];
handler.tags = ["fun"];
handler.command = /^(dare)$/i;

export default handler;
