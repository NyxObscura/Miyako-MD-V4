/* 
『WARNING』 WATERMARK INI TIDAK BOLEH DI HAPUS
* SCRIPT BY DEXZZ
* NAMA SCRIPT EMILIA-MD
* JANGAN DI HAPUS KONTOL
* FOLLOW SALURAN DEXZZ
https://whatsapp.com/channel/0029ValeNDG0LKZLbAQZNs0i
*/
import axios from "axios";

let handler = async (m, { conn }) => {
  global.db.data.settings[conn.user.jid].loading
    ? await m.reply(global.config.loading)
    : false;
  let url = await axios.get(
    "https://raw.githubusercontent.com/veann-xyz/result-daniapi/main/cecan/cogan.json",
  );
  let image = url.data.getRandom();
  conn.sendFile(m.chat, image, "cogan.jpeg", null, m, false);
};
handler.help = ["cogan"];
handler.tags = ["internet"];
handler.command = /^(cogan)$/i;
handler.limit = true; handler.error = 0
export default handler;
