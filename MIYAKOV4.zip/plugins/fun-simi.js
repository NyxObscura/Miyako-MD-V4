/* 
『WARNING』 WATERMARK INI TIDAK BOLEH DI HAPUS
* SCRIPT BY DEXZZ
* NAMA SCRIPT EMILIA-MD
* JANGAN DI HAPUS KONTOL
* FOLLOW SALURAN DEXZZ
https://whatsapp.com/channel/0029ValeNDG0LKZLbAQZNs0i
*/
import { simi } from "../lib/scrape.js";
let handler = async (m, { conn, text }) => {
  if (!text) return m.reply("Mau ngomong apa kak sama simi?");
  try {
    let teks = await simi(text, "id");
    m.reply(teks, false, false, { smlcap: false });
  } catch (e) {
    return m.reply("Maaf kak aku ga paham hehehe...");
  }
};
handler.help = ["simi"];
handler.tags = ["fun"];
handler.command = /^(simi)$/i;
handler.onlyprem = true;
handler.limit = true; handler.error = 0
export default handler;
