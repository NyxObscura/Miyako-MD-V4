/* 
『WARNING』 WATERMARK INI TIDAK BOLEH DI HAPUS
* SCRIPT BY DEXZZ
* NAMA SCRIPT EMILIA-MD
* JANGAN DI HAPUS KONTOL
* FOLLOW SALURAN DEXZZ
https://whatsapp.com/channel/0029ValeNDG0LKZLbAQZNs0i
*/
import { geminiChat } from "../lib/gemini.js";

const handler = async (m, { conn, text }) => {
  if (!text)
    return m.reply("Masukan commandnya\n> *contoh:* .gemini Halo atau .gemini Del untuk menghapus session");

  try {
    if (/del/i.test(text)) {
      delete global.db.data.users[m.sender].gemini;
      m.reply("Berhasil menghapus sesi");
    } else {
      const anu = await conn.sendMessage(m.chat, { text: wait }, { quoted: m });
      const chat = await geminiChat(text, m);
      await conn.editMessage(m.chat, anu.key, chat, m);
    }
  } catch (e) {
    m.reply(e.message);
  }
};

handler.command = ["ge"];
export default handler;
