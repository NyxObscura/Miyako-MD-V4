/* 
『WARNING』 WATERMARK INI TIDAK BOLEH DI HAPUS
* SCRIPT BY XENZ
* CODE BY XENZ
* NAMA SCRIPT MIYAKO-TSUKIYUKI
* JANGAN DI HAPUS KONTOL
* FOLLOW SALURAN XENZ
https://whatsapp.com/channel/0029ValeNDG0LKZLbAQZNs0i
*/

export async function before(m) {
  this.ev.on("call", async (call) => {
    if (
      call[0].status == "offer" &&
      global.db.data.settings[this.user.jid].anticall
    )
      await this.rejectCall(call[0].id, call[0].from);
  });
  return !0;
}
