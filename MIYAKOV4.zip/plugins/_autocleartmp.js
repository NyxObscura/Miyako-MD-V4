/* 
『WARNING』 WATERMARK INI TIDAK BOLEH DI HAPUS
* SCRIPT BY XENZ
* CODE BY XENZ
* NAMA SCRIPT MIYAKO-TSUKIYUKI
* JANGAN DI HAPUS KONTOL
* FOLLOW SALURAN XENZ
https://whatsapp.com/channel/0029ValeNDG0LKZLbAQZNs0i
*/

import { readdirSync, rmSync } from "fs";
export async function all(m) {
  let setting = global.db.data.settings[this.user.jid];
  if (setting.cleartmp) {
    if (new Date() * 1 - setting.lastcleartmp > 600000) {
      const dir = "./tmp";
      readdirSync(dir).forEach((f) => rmSync(`${dir}/${f}`));
      setting.lastcleartmp = new Date() * 1;
    }
  }
  return !0;
}
