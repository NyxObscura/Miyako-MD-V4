/* 
『WARNING』 WATERMARK INI TIDAK BOLEH DI HAPUS
* SCRIPT BY DEXZZ
* NAMA SCRIPT EMILIA-MD
* JANGAN DI HAPUS KONTOL
* FOLLOW SALURAN DEXZZ
https://whatsapp.com/channel/0029ValeNDG0LKZLbAQZNs0i
*/
let handler = async (m, { usedPrefix }) => {
  let id = m.chat;
  if (!(id in global.db.data.bots.absen))
    return m.reply(`_*Tidak ada absen berlangsung digrup ini!*_\n\n*${usedPrefix}mulaiabsen* - untuk memulai absen`);
  delete global.db.data.bots.absen[id];
  m.reply(`Done!`);
};
handler.help = ["hapusabsen"];
handler.tags = ["group"];
handler.command = /^(delete|hapus)absen$/i;
handler.group = true;
handler.admin = true;
export default handler;
