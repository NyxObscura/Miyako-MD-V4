/* 
『WARNING』 WATERMARK INI TIDAK BOLEH DI HAPUS
* SCRIPT BY DEXZZ
* NAMA SCRIPT EMILIA-MD
* JANGAN DI HAPUS KONTOL
* FOLLOW SALURAN DEXZZ
https://whatsapp.com/channel/0029ValeNDG0LKZLbAQZNs0i
*/
let handler = async (m, { conn }) => {
  var ayg = global.db.data.users[m.sender];
  var beb = global.db.data.users[global.db.data.users[m.sender].pacar];

  if (ayg.pacar == "") {
    return conn.reply(m.chat, `Kamu Tdak Memiliki pacar.`, m);
  }
  if (typeof beb == "undefined") {
    conn.reply(
      m.chat,
      `Berhasil Putus Hubungan Dengan @${global.db.data.users[m.sender].pacar.split("@")[0]}`,
      m,
      {
        contextInfo: {
          mentionedJid: [global.db.data.users[m.sender].pacar],
        },
      },
    );
    ayg.pacar = "";
  }

  if (m.sender == beb.pacar) {
    conn.reply(
      m.chat,
      `Berhasil Putus Hubungan Dengan @${global.db.data.users[m.sender].pacar.split("@")[0]}`,
      m,
      {
        contextInfo: {
          mentionedJid: [global.db.data.users[m.sender].pacar],
        },
      },
    );
    ayg.pacar = "";
    beb.pacar = "";
  } else {
    conn.reply(m.chat, `Kamu Tidak Memiliki pacar.`, m);
  }
};
handler.help = ["putus"];
handler.tags = ["group", "fun"];
handler.command = /^(putus)$/i;
handler.group = true;
handler.fail = null;
export default handler;
